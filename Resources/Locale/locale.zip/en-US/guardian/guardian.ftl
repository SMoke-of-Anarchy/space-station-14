## Guardian host specific

guardian-created = You feel... Haunted.
guardian-already-present-invalid-creation = You are NOT re-living that haunting experience!
guardian-no-actions-invalid-creation = You don't have the ability to host a guardian!
guardian-activator-invalid-target = {CAPITALIZE(THE($entity))} is incapable of hosting a guardian!
guardian-no-soul = Your guardian has no soul.
guardian-available = Your guardian now has a soul.
guardian-inside-container = There's no room to release your guardian!

## Injector specific
guardian-injector-empty-invalid-creation = The injector is spent.
guardian-injector-empty-examine = [color=#ba1919]The injector is spent.[/color]

## Guardian deck specific

guardian-deck-invalid-creation = The deck can only provide one guardian at a time!
guardian-deck-used-examine = [color=#ba1919]The deck's magic has been used up.[/color]

## Guardian entity specific

guardian-entity-recall = The guardian vanishes into thin air!
guardian-entity-taking-damage = Your guardian is taking damage!

## Health warnings
guardian-host-critical-warn = YOUR HOST IS WOUNDED!
guardian-host-death-warn = YOUR FORM SUCCUMBS TO NONEXISTENCE!
guardian-death-warn = YOUR BODY IS PIERCED BY SUBATOMIC PAIN AS IT DISINTEGRATES!
guardian-attack-host = You cannot attack your host.

