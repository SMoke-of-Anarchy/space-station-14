comp-gas-mixer-ui-mixer-output-pressure = Output Pressure (kPa):

comp-gas-mixer-ui-mixer-node-back = Back Port:
comp-gas-mixer-ui-mixer-node-side = Side Port:

comp-gas-mixer-ui-mixer-set = Set
comp-gas-mixer-ui-mixer-max = Max

comp-gas-mixer-ratio-examine = The side port ratio is [color={$statusColor}]{$sidePortRatio}[/color].
