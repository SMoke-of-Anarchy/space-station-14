## UI

ui-disposal-unit-title = {CAPITALIZE($name)}

ui-disposal-unit-label-state = State:
ui-disposal-unit-label-pressure = Pressure:
ui-disposal-unit-label-status = Ready

ui-disposal-unit-button-flush = Flush
ui-disposal-unit-button-eject = Eject Contents
ui-disposal-unit-button-routing = Routing
ui-disposal-unit-button-power = Power

## Verbs
disposal-flush-verb-get-data-text = Flush
disposal-eject-verb-get-data-text = Eject contents

## Errors
disposal-unit-no-hands = You don't have hands!
disposal-unit-is-full = There's no more room inside.

# state
disposal-unit-state-Ready = Ready
# Yes I want it to always say Pressurizing
disposal-unit-state-Flushed = Pressurizing
disposal-unit-state-Pressurizing = Pressurizing
disposal-unit-state-Unpowered = Unpowered

# putting people in
disposal-unit-being-inserted = {CAPITALIZE($user)} is trying to force you into a disposal chute!
