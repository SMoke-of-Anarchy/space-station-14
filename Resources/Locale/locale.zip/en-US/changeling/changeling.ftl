# antag selection
roles-antag-changeling-name = Changeling
roles-antag-changeling-objective = Use shapeshifting and mutations to hide among the crew and devour them unnoticed.

# devour
changeling-devour-attempt-failed-cannot-devour = We cannot devour this!
changeling-devour-attempt-failed-already-devoured = We already consumed this body!
changeling-devour-attempt-failed-devoured-recently = This body is too mangled to devour!
changeling-devour-attempt-failed-not-dead = This body yet lives! We cannot consume it alive!
changeling-devour-attempt-failed-rotting = This corpse has only rotted biomass.
changeling-devour-attempt-failed-protected = This victim's biomass is protected by armor!
changeling-devour-attempt-failed-no-space = We have exceeded the maximum number of disguises!

changeling-devour-begin-windup-self = Our uncanny mouth reveals itself with otherworldly hunger.
changeling-devour-begin-windup-others = { CAPITALIZE(POSS-ADJ($user)) } uncanny mouth reveals itself with otherworldly hunger.
changeling-devour-begin-consume-self = The uncanny mouth digs deep into its victim.
changeling-devour-begin-consume-others = { CAPITALIZE(POSS-ADJ($user)) } uncanny mouth digs deep into { POSS-ADJ($user) } victim.
changeling-devour-consume-complete-self = Our uncanny mouth retreats, biomass consumed.
changeling-devour-consume-complete-others = { CAPITALIZE(POSS-ADJ($user)) } uncanny mouth retreats.

changeling-devour-doafter-windup = [color=red]{ CAPITALIZE(POSS-ADJ($user)) } face is splitting open, preparing to feast![/color]
changeling-devour-doafter = [color=red]{ CAPITALIZE(SUBJECT($user)) } { CONJUGATE-BE($user) } tearing into the flesh of {$target}![/color]

# transformation
changeling-transform-attempt-self = Our bones snap, muscles tear, one flesh becomes another.
changeling-transform-attempt-others = { CAPITALIZE(POSS-ADJ($user)) } bones snap, muscles tear, body shifts into another.

changeling-transform-doafter = [color=red]The surface of { POSS-ADJ($user) } skin is melting, taking another shape.[/color]

# transformation BUI
changeling-transform-bui-select-entity = {$entity}
changeling-transform-bui-drop-identity-menu = Drop a devoured identity from your memory.
changeling-transform-bui-drop-identity-entity = Drop {$entity}
changeling-transform-bui-drop-identity-entity-popup = We dropped {$entity} from our memory.
changeling-transform-bui-drop-identity-cannot-drop = We cannot drop our current identity.

# voice mimicry
changeling-voice-mimic-window-title = Voice Mimicry

# flesh clothing
changeling-flesh-clothing-removed-popop = {CAPITALIZE(THE($item))} falls apart into fleshy remains!
changeling-flesh-clothing-examine-wearer = [color=crimson]This item is a camouflaged part of your body. It will disappear if you unequip it![/color]
changeling-flesh-clothing-alert-name = Flesh Clothing Ability
changeling-flesh-clothing-alert-desc = Whether clothing transformation is enabled. Click to toggle.

# biodegrade
changeling-biodegrade-used-popup = {CAPITALIZE(THE($user))} vomits acid over {POSS-ADJ($user)} {$restraint}!
changeling-biodegrade-used-popup-self = We vomit acid over our {$restraint}!

# last resort
changeling-takeover-not-dead = This body yet lives! We cannot infest it alive.
changeling-takeover-is-changeling = This body rejects our attempts to take over!
changeling-takeover-start-others = {CAPITALIZE(THE($user))} begins to crawl inside the corpse!
changeling-takeover-doafter = [color=red]{ CAPITALIZE(SUBJECT($user)) } { CONJUGATE-BE($user) } crawling inside of {$target}![/color]

# stings
changeling-sting-success = We silently sting {THE($target)}!
changeling-sting-hemotoxin = You feel sharp pain in your chest!

# mindshield
changeling-fake-mindshield-enabled = We emit fake mindshield waves.
changeling-fake-mindshield-disabled = We stop emitting fake mindshield waves.

# chemicals
changeling-not-enough-chemicals = We don't have enough Chemicals.

# other
changeling-action-fail-generic = We cannot do this right now.
changeling-paused-map-name = Changeling identity storage map
changeling-cocoon-success = We encase {THE($target)} in a fleshy tomb.
changeling-cocoon-doafter = [color=red]{ CAPITALIZE(SUBJECT($user)) } { CONJUGATE-BE($user) } covering { THE($target) } in a fleshy mass![/color]

# horror transformation
changeling-horror-alert-time-name = Remaining time
changeling-horror-alert-time-desc = When this counter reaches 0, we will have exhausted our strength.
changeling-horror-force-transform-self = Our energy depleted, we cannot maintain this form anymore.
changeling-horror-force-transform-others = { CAPITALIZE(POSS-ADJ($user)) } flesh rapidly shrivels away and dies.
changeling-horror-transform-fail = We do not have enough DNA stored to reveal ourselves.
