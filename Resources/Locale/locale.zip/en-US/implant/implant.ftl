## Implanter Attempt Messages

implanter-component-implanting-target = {CAPITALIZE(THE({$user}))} is trying to implant you with something!
implanter-component-draw-target = {CAPITALIZE(THE({$user}))} is trying to extract something from you!
implanter-component-implant-failed = The {$implant} cannot be given to {$target}!
implanter-draw-failed-permanent = The {$implant} in {$target} is fused with { OBJECT($target) } and cannot be removed!
implanter-draw-failed = You tried to remove an implant but found nothing.
implanter-draw-failed-catastrophically = The implanter finds nothing and catastrophically fails, shunting genetic material into {$user}'s hand!
implanter-component-implant-already = {CAPITALIZE(THE({$target}))} already has the {$implant}!

## UI
implanter-set-draw-verb = Set Implant Draw
implanter-set-draw-window = Set Implant Draw
implanter-set-draw-info = Select the implant type this implanter should remove:
implanter-set-draw-type = Implant type:

implanter-draw-text = Draw
implanter-inject-text = Inject

implanter-empty-text = Empty

implanter-label-inject = [color=green]{$implantName}[/color]
    Mode: [color=white]{$modeString}[/color]

implanter-label-draw = [color=red]{$implantName}[/color]
    Mode: [color=white]{$modeString}[/color]

implanter-contained-implant-text = [color=green]{$desc}[/color]
