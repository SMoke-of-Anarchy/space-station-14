reflect-shot = Reflected!
