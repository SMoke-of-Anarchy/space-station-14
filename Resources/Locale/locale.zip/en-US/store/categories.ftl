# Uplink
store-category-debug = debug category
store-category-debug2 = debug category 2
store-category-weapons = Weaponry
store-category-ammo = Ammo
store-category-explosives = Explosives
store-category-chemicals = Chemicals
store-category-deception = Deception
store-category-disruption = Disruption
store-category-implants = Implants
store-category-allies = Allies
store-category-job = Job
store-category-wearables = Wearables
store-category-pointless = Pointless
store-category-objective = Objective
store-discounted-items = Discounts

# Revenant
store-category-abilities = Abilities

# Wizard
store-caregory-spellbook-offensive = Offensive Spells
store-caregory-spellbook-defensive = Defensive Spells
store-caregory-spellbook-utility = Utility Spells
store-caregory-spellbook-equipment = Wizard Equipment
store-caregory-spellbook-events = Event Spells

# Nukie Delivery
store-category-nukie-delivery = Offers

# Changeling
store-category-combat = Combat
store-category-utility = Utility
store-category-stealth = Stealth
